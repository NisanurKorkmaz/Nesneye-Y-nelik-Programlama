/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

//NISANUR YADIGAR KORKMAZ 170201102

public class Ders {
    int dersSayisi;
    int dersKredisi;
    int dersNotu;

    public int getDersSayisi() {
        return dersSayisi;
    }

    public int getDersKredisi() {
        return dersKredisi;
    }

    public int getDersNotu() {
        return dersNotu;
    }

    public void setDersSayisi(int dersSayisi) {
        this.dersSayisi = dersSayisi;
    }

    public void setDersKredisi(int dersKredisi) {
        this.dersKredisi = dersKredisi;
    }

    public void setDersNotu(int dersNotu) {
        this.dersNotu = dersNotu;
    }
    
    
}
